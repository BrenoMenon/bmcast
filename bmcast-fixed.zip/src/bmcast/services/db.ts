import {
  Screen,
  MediaItem,
  Playlist,
  SystemConfig,
  TickerConfig,
  WeatherConfig,
  CompanyBrandProfile,
  PlaylistItem,
} from '../types/signage';
import { weatherService } from './weatherService';
import { supabaseService, DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_KEY } from './supabaseClient';

export const DB_CHANGE_EVENT = 'bmcast_db_changed';

const STORAGE_KEYS = {
  SCREENS: 'bmcast_screens_clean_v6',
  MEDIA: 'bmcast_media_clean_v6',
  PLAYLISTS: 'bmcast_playlists_clean_v6',
  CONFIG: 'bmcast_config_clean_v6',
  TICKER: 'bmcast_ticker_clean_v6',
  WEATHER: 'bmcast_weather_clean_v6',
  LAST_SYNC: 'bmcast_supabase_last_sync',
};

export const DEMO_PRESET_PACK: MediaItem[] = [
  {
    id: 'demo-slide-1',
    title: 'Hambúrguer Artesanal Smash Duplo',
    type: 'image',
    url: '/demo-burger.jpg',
    thumbnail: '/demo-burger.jpg',
    durationDefault: 12,
    category: 'cardapio',
    createdAt: new Date().toISOString(),
    categoryOverlay: {
      badgeText: 'MAIS PEDIDO',
      headline: 'Hambúrguer Artesanal Smash Duplo',
      subheadline: 'Acompanha batata rústica crocante e bebida gelada artesanal',
      priceOriginal: 'R$ 44,90',
      pricePromo: 'R$ 32,90',
      showPriceTag: true,
      showOverlayBadge: true,
      accentColor: '#2563EB',
      discountPercent: '25% OFF',
    },
    qrConfig: {
      showQrCode: true,
      qrCodeType: 'generated',
      qrCodeUrl: 'https://bmcast.app',
      qrCodeLabel: 'Peça pelo WhatsApp',
      qrCodePosition: 'bottom-right',
      qrCodeSize: 'medium',
    },
    brandConfig: {
      showBrand: true,
      brandName: 'BM Burger & Craft',
      brandSlogan: 'O melhor sabor artesanal da cidade',
      brandPosition: 'top-left',
      accentColor: '#2563EB',
    },
  },
  {
    id: 'demo-slide-2',
    title: 'Super Combo Família Pizza Artesanal',
    type: 'image',
    url: '/demo-pizza.jpg',
    thumbnail: '/demo-pizza.jpg',
    durationDefault: 12,
    category: 'promo',
    createdAt: new Date().toISOString(),
    categoryOverlay: {
      badgeText: 'PROMOÇÃO DA SEMANA',
      headline: 'Pizza Grande Artesanal + Borda Recheada',
      subheadline: 'Massa de fermentação natural de 48h com queijo importado',
      priceOriginal: 'R$ 79,90',
      pricePromo: 'R$ 54,90',
      showPriceTag: true,
      showOverlayBadge: true,
      accentColor: '#059669',
      discountPercent: '30% OFF',
    },
    qrConfig: {
      showQrCode: true,
      qrCodeType: 'generated',
      qrCodeUrl: 'https://bmcast.app',
      qrCodeLabel: 'Cardápio Completo',
      qrCodePosition: 'bottom-right',
      qrCodeSize: 'medium',
    },
    brandConfig: {
      showBrand: true,
      brandName: 'BM Pizza Gourmet',
      brandSlogan: 'Tradição e Forno a Lenha',
      brandPosition: 'top-left',
      accentColor: '#059669',
    },
  },
];

const DEFAULT_BRAND_PROFILE: CompanyBrandProfile = {
  name: '',
  slogan: '',
  logoUrl: '',
  accentColor: '#2563EB',
  phoneWhatsApp: '',
  instagramHandle: '',
  websiteUrl: '',
  defaultQrCodeUrl: '',
  defaultQrCodeImage: '',
  businessCategory: 'outro',
  onboardingCompleted: false,
  supabaseUrl: DEFAULT_SUPABASE_URL,
  supabaseAnonKey: DEFAULT_SUPABASE_KEY,
  supabaseConnected: true,
};

const DEFAULT_CONFIG: SystemConfig = {
  organizationName: '',
  brandProfile: DEFAULT_BRAND_PROFILE,
  themeAccent: '#2563EB',
  themeMode: 'dark',
  defaultLayoutMode: 'clean_media',
  enableSplitMode: true,
};

const DEFAULT_TICKER: TickerConfig = {
  enabled: true,
  text: 'BM CAST • Sistema Profissional de TV e Mídia Indoor • Conectado ao Supabase.',
  speed: 'normal',
  accentTitle: 'AVISO AO VIVO',
  presetTopic: 'retail',
};

const DEFAULT_WEATHER: WeatherConfig = {
  autoDetect: false,
  city: 'São Paulo',
  stateCode: 'SP',
  latitude: -23.5505,
  longitude: -46.6333,
  temp: 24,
  tempMin: 18,
  tempMax: 27,
  condition: 'partly_cloudy',
  conditionText: 'Parcialmente Nublado',
  humidity: 58,
  windKmH: 12,
  lastFetchedAt: new Date().toISOString(),
  source: 'open_meteo_live',
};

class ResilientDatabase {
  private screens: Screen[] = [];
  private media: MediaItem[] = [];
  private playlists: Playlist[] = [];
  private config: SystemConfig = DEFAULT_CONFIG;
  private ticker: TickerConfig = DEFAULT_TICKER;
  private weather: WeatherConfig = DEFAULT_WEATHER;
  private broadcastChannel: BroadcastChannel | null = null;
  private realtimeChannel: any = null;
  private isSupabaseSyncing = false;
  private lastSyncTime: string | null = null;

  constructor() {
    this.initBroadcast();
    this.loadFromStorage();
    this.refreshWeatherPeriodically();
    this.initSupabaseSync();
  }

  private initBroadcast() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.broadcastChannel = new BroadcastChannel('bmcast_sync_channel');
        this.broadcastChannel.onmessage = (ev) => {
          if (ev.data && ev.data.type === 'DB_SYNC') {
            this.loadFromStorage();
            this.notifyListeners(false);
          }
        };
      } catch (e) {
        console.warn('BroadcastChannel not available:', e);
      }
    }
  }

  private notifyListeners(broadcast = true) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(DB_CHANGE_EVENT));
      if (broadcast && this.broadcastChannel) {
        this.broadcastChannel.postMessage({ type: 'DB_SYNC', timestamp: Date.now() });
      }
    }
  }

  private loadFromStorage() {
    if (typeof window === 'undefined') return;

    try {
      const storedScreens = localStorage.getItem(STORAGE_KEYS.SCREENS);
      this.screens = storedScreens ? JSON.parse(storedScreens) : [];

      const storedMedia = localStorage.getItem(STORAGE_KEYS.MEDIA);
      this.media = storedMedia ? JSON.parse(storedMedia) : [];

      const storedPlaylists = localStorage.getItem(STORAGE_KEYS.PLAYLISTS);
      this.playlists = storedPlaylists ? JSON.parse(storedPlaylists) : [];

      const storedConfig = localStorage.getItem(STORAGE_KEYS.CONFIG);
      this.config = storedConfig ? JSON.parse(storedConfig) : DEFAULT_CONFIG;

      // Ensure default credentials exist if empty
      if (!this.config.brandProfile.supabaseUrl) {
        this.config.brandProfile.supabaseUrl = DEFAULT_SUPABASE_URL;
        this.config.brandProfile.supabaseAnonKey = DEFAULT_SUPABASE_KEY;
        this.config.brandProfile.supabaseConnected = true;
      }

      const storedTicker = localStorage.getItem(STORAGE_KEYS.TICKER);
      this.ticker = storedTicker ? JSON.parse(storedTicker) : DEFAULT_TICKER;

      const storedWeather = localStorage.getItem(STORAGE_KEYS.WEATHER);
      this.weather = storedWeather ? JSON.parse(storedWeather) : DEFAULT_WEATHER;

      this.lastSyncTime = localStorage.getItem(STORAGE_KEYS.LAST_SYNC);
    } catch (e) {
      console.error('Erro ao ler dados locais:', e);
      this.screens = [];
      this.media = [];
      this.playlists = [];
      this.config = DEFAULT_CONFIG;
      this.ticker = DEFAULT_TICKER;
      this.weather = DEFAULT_WEATHER;
    }
  }

  private saveToStorage() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEYS.SCREENS, JSON.stringify(this.screens));
      localStorage.setItem(STORAGE_KEYS.MEDIA, JSON.stringify(this.media));
      localStorage.setItem(STORAGE_KEYS.PLAYLISTS, JSON.stringify(this.playlists));
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(this.config));
      localStorage.setItem(STORAGE_KEYS.TICKER, JSON.stringify(this.ticker));
      localStorage.setItem(STORAGE_KEYS.WEATHER, JSON.stringify(this.weather));
      this.notifyListeners();
    } catch (e) {
      console.error('Erro ao gravar dados no storage:', e);
    }
  }

  // --- SUPABASE SYNC LOGIC ---

  private async initSupabaseSync() {
    if (typeof window === 'undefined') return;

    setTimeout(() => {
      if (!supabaseService.isSchemaKnownMissing()) {
        this.syncFromSupabase();
        this.setupRealtimeSubscription();
      }
    }, 1000);
  }

  private getActiveCloudClient() {
    if (supabaseService.isSchemaKnownMissing()) return null;
    return supabaseService.getClient();
  }

  private setupRealtimeSubscription() {
    const client = this.getActiveCloudClient();
    if (!client) return;

    try {
      if (this.realtimeChannel) {
        client.removeChannel(this.realtimeChannel);
      }

      this.realtimeChannel = client
        .channel('bmcast_realtime_changes')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public' },
          (payload) => {
            console.log('[BM CAST Realtime] Atualização remota recebida:', payload);
            this.syncFromSupabase(false);
          }
        )
        .subscribe();
    } catch (e) {
      console.warn('Realtime subscription not supported or table missing:', e);
    }
  }

  /**
   * Baixa dados atualizados do Supabase (screens, playlists, media, etc.)
   */
  async syncFromSupabase(pushLocalIfRemoteEmpty = true): Promise<{ success: boolean; message: string }> {
    const client = supabaseService.getClient();
    if (!client) {
      return { success: false, message: 'Cliente Supabase não configurado.' };
    }

    if (this.isSupabaseSyncing) {
      return { success: true, message: 'Sincronização já em andamento.' };
    }

    this.isSupabaseSyncing = true;
    try {
      // 1. Screens (also acts as schema probe to prevent 5x 404s if tables aren't created yet)
      const { data: screensData, error: screensErr } = await client
        .from('screens')
        .select('*');

      if (screensErr) {
        if (
          screensErr.code === 'PGRST205' ||
          screensErr.code === '42P01' ||
          screensErr.message.includes('Could not find the table') ||
          screensErr.message.includes('does not exist')
        ) {
          supabaseService.markSchemaStatus(false);
          return {
            success: false,
            message: 'Conectado ao Supabase! Execute o Script SQL no SQL Editor para criar as tabelas.',
          };
        }
      } else {
        supabaseService.markSchemaStatus(true);
      }

      if (!screensErr && screensData && screensData.length > 0) {
        this.screens = screensData.map((s: any) => ({
          id: s.id,
          name: s.name,
          location: s.location || '',
          slug: s.slug,
          pairingCode: s.pairing_code || '',
          activePlaylistId: s.active_playlist_id || '',
          status: s.status || 'online',
          resolution: s.resolution || '1080p',
          orientation: s.orientation || 'landscape',
          aspectRatio: s.aspect_ratio || '16:9',
          layoutMode: s.layout_mode || 'clean_media',
          brandName: s.brand_name || undefined,
          brandSlogan: s.brand_slogan || undefined,
          brandLogo: s.brand_logo || undefined,
          lastPing: s.last_ping || new Date().toISOString(),
          pairedAt: s.paired_at || new Date().toISOString(),
          notes: s.notes || undefined,
        }));
      }

      // 2. Media
      const { data: mediaData, error: mediaErr } = await client
        .from('media')
        .select('*');

      if (!mediaErr && mediaData && mediaData.length > 0) {
        this.media = mediaData.map((m: any) => ({
          id: m.id,
          title: m.title,
          type: m.type || 'image',
          url: m.url,
          thumbnail: m.thumbnail || undefined,
          durationDefault: m.duration_default || 12,
          category: m.category || 'cardapio',
          brandConfig: m.brand_config || undefined,
          qrConfig: m.qr_config || undefined,
          categoryOverlay: m.category_overlay || undefined,
          fileSize: m.file_size || undefined,
          dimensions: m.dimensions || undefined,
          createdAt: m.created_at || new Date().toISOString(),
        }));
      }

      // 3. Playlists
      const { data: plData, error: plErr } = await client
        .from('playlists')
        .select('*');

      if (!plErr && plData && plData.length > 0) {
        this.playlists = plData.map((p: any) => ({
          id: p.id,
          name: p.name,
          description: p.description || '',
          screenId: p.screen_id || 'all',
          items: Array.isArray(p.items) ? p.items : [],
          isDefault: Boolean(p.is_default),
          updatedAt: p.updated_at || new Date().toISOString(),
        }));
      }

      // 4. System Config
      const { data: cfgData, error: cfgErr } = await client
        .from('system_config')
        .select('*')
        .eq('id', 'default')
        .maybeSingle();

      if (!cfgErr && cfgData) {
        this.config = {
          organizationName: cfgData.organization_name || this.config.organizationName,
          brandProfile: {
            ...this.config.brandProfile,
            ...(cfgData.brand_profile || {}),
          },
          themeAccent: cfgData.theme_accent || this.config.themeAccent,
          themeMode: cfgData.theme_mode || this.config.themeMode,
          defaultLayoutMode: cfgData.default_layout_mode || this.config.defaultLayoutMode,
          enableSplitMode: cfgData.enable_split_mode !== undefined ? cfgData.enable_split_mode : this.config.enableSplitMode,
        };
      }

      // 5. Ticker
      const { data: tickerData, error: tickerErr } = await client
        .from('ticker_config')
        .select('*')
        .eq('id', 'default')
        .maybeSingle();

      if (!tickerErr && tickerData) {
        this.ticker = {
          enabled: Boolean(tickerData.enabled),
          text: tickerData.text || this.ticker.text,
          speed: tickerData.speed || 'normal',
          accentTitle: tickerData.accent_title || this.ticker.accentTitle,
          presetTopic: tickerData.preset_topic || 'retail',
        };
      }

      // Se temos dados locais e a tabela remota estava vazia, faz o push inicial
      if (
        pushLocalIfRemoteEmpty &&
        screensData &&
        screensData.length === 0 &&
        this.screens.length > 0
      ) {
        this.pushAllToSupabase();
      }

      this.lastSyncTime = new Date().toISOString();
      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEYS.LAST_SYNC, this.lastSyncTime);
      }
      this.saveToStorage();

      return {
        success: true,
        message: 'Sincronização com o Supabase concluída com sucesso.',
      };
    } catch (e: any) {
      console.warn('Erro ao sincronizar do Supabase:', e);
      return {
        success: false,
        message: 'Erro durante a sincronização com o Supabase: ' + (e?.message || 'Verifique as tabelas'),
      };
    } finally {
      this.isSupabaseSyncing = false;
    }
  }

  /**
   * Envia todos os dados locais para o Supabase (Screens, Media, Playlists, Config, Ticker)
   */
  async pushAllToSupabase(): Promise<{ success: boolean; message: string }> {
    const client = supabaseService.getClient();
    if (!client) {
      return { success: false, message: 'Cliente Supabase não configurado.' };
    }

    try {
      // Probe schema first so we return a clear message instead of 5 failed requests
      const probe = await client.from('system_config').select('id').limit(1);
      if (
        probe.error &&
        (probe.error.code === 'PGRST205' ||
          probe.error.code === '42P01' ||
          probe.error.message.includes('Could not find the table') ||
          probe.error.message.includes('does not exist'))
      ) {
        supabaseService.markSchemaStatus(false);
        return {
          success: false,
          message: 'As tabelas ainda não existem no seu projeto Supabase. Copie o Script SQL abaixo e execute no SQL Editor!',
        };
      }
      supabaseService.markSchemaStatus(true);
      // 1. Screens
      if (this.screens.length > 0) {
        const rows = this.screens.map((s) => ({
          id: s.id,
          name: s.name,
          location: s.location,
          slug: s.slug,
          pairing_code: s.pairingCode,
          active_playlist_id: s.activePlaylistId,
          status: s.status,
          resolution: s.resolution,
          orientation: s.orientation,
          aspect_ratio: s.aspectRatio,
          layout_mode: s.layoutMode || 'clean_media',
          brand_name: s.brandName || null,
          brand_slogan: s.brandSlogan || null,
          brand_logo: s.brandLogo || null,
          last_ping: s.lastPing,
          paired_at: s.pairedAt,
          notes: s.notes || null,
        }));
        await client.from('screens').upsert(rows);
      }

      // 2. Media
      if (this.media.length > 0) {
        const rows = this.media.map((m) => ({
          id: m.id,
          title: m.title,
          type: m.type,
          url: m.url,
          thumbnail: m.thumbnail || null,
          duration_default: m.durationDefault,
          category: m.category,
          brand_config: m.brandConfig || null,
          qr_config: m.qrConfig || null,
          category_overlay: m.categoryOverlay || null,
          file_size: m.fileSize || null,
          dimensions: m.dimensions || null,
        }));
        await client.from('media').upsert(rows);
      }

      // 3. Playlists
      if (this.playlists.length > 0) {
        const rows = this.playlists.map((p) => ({
          id: p.id,
          name: p.name,
          description: p.description,
          screen_id: p.screenId || 'all',
          items: p.items,
          is_default: p.isDefault || false,
          updated_at: p.updatedAt,
        }));
        await client.from('playlists').upsert(rows);
      }

      // 4. Config
      await client.from('system_config').upsert({
        id: 'default',
        organization_name: this.config.organizationName,
        brand_profile: this.config.brandProfile,
        theme_accent: this.config.themeAccent,
        theme_mode: this.config.themeMode,
        default_layout_mode: this.config.defaultLayoutMode,
        enable_split_mode: this.config.enableSplitMode,
        updated_at: new Date().toISOString(),
      });

      // 5. Ticker
      await client.from('ticker_config').upsert({
        id: 'default',
        enabled: this.ticker.enabled,
        text: this.ticker.text,
        speed: this.ticker.speed,
        accent_title: this.ticker.accentTitle || 'AVISO AO VIVO',
        preset_topic: this.ticker.presetTopic || 'retail',
        updated_at: new Date().toISOString(),
      });

      this.lastSyncTime = new Date().toISOString();
      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEYS.LAST_SYNC, this.lastSyncTime);
      }

      return {
        success: true,
        message: 'Todos os dados foram enviados para o Supabase com sucesso!',
      };
    } catch (e: any) {
      console.warn('Erro ao enviar dados para o Supabase:', e);
      return {
        success: false,
        message: 'Erro ao enviar dados: ' + (e?.message || 'Verifique se as tabelas existem no Supabase.'),
      };
    }
  }

  private async refreshWeatherPeriodically() {
    setTimeout(async () => {
      try {
        const live = await weatherService.fetchLiveWeather(
          this.weather.latitude || -23.5505,
          this.weather.longitude || -46.6333,
          this.weather.city || 'São Paulo',
          this.weather.stateCode || 'SP'
        );
        this.weather = live;
        this.saveToStorage();
      } catch (err) {
        console.warn('Erro ao atualizar clima inicial:', err);
      }
    }, 1500);

    if (typeof window !== 'undefined') {
      setInterval(async () => {
        try {
          const live = await weatherService.fetchLiveWeather(
            this.weather.latitude || -23.5505,
            this.weather.longitude || -46.6333,
            this.weather.city || 'São Paulo',
            this.weather.stateCode || 'SP'
          );
          this.weather = live;
          this.saveToStorage();
        } catch (e) {
          console.warn('Erro ao renovar clima periódico:', e);
        }
      }, 15 * 60 * 1000);
    }
  }

  // --- Screens CRUD ---
  getScreens(): Screen[] {
    return [...this.screens];
  }

  getScreenBySlug(slug: string): Screen | undefined {
    const clean = slug.toLowerCase().trim();
    return this.screens.find((s) => s.slug.toLowerCase().trim() === clean);
  }

  saveScreen(screen: Screen): void {
    const idx = this.screens.findIndex((s) => s.id === screen.id);
    const updated = { ...screen, lastPing: new Date().toISOString() };
    if (idx >= 0) {
      this.screens[idx] = updated;
    } else {
      this.screens.push(updated);
    }
    this.saveToStorage();

    // Supabase background sync
    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('screens')
        .upsert({
          id: updated.id,
          name: updated.name,
          location: updated.location,
          slug: updated.slug,
          pairing_code: updated.pairingCode,
          active_playlist_id: updated.activePlaylistId,
          status: updated.status,
          resolution: updated.resolution,
          orientation: updated.orientation,
          aspect_ratio: updated.aspectRatio,
          layout_mode: updated.layoutMode || 'clean_media',
          brand_name: updated.brandName || null,
          brand_slogan: updated.brandSlogan || null,
          brand_logo: updated.brandLogo || null,
          last_ping: updated.lastPing,
          paired_at: updated.pairedAt,
          notes: updated.notes || null,
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase screen save warning:', error.message);
        }, () => {});
    }
  }

  deleteScreen(id: string): void {
    this.screens = this.screens.filter((s) => s.id !== id);
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('screens')
        .delete()
        .eq('id', id)
        .then(({ error }) => {
          if (error) console.warn('Supabase screen delete warning:', error.message);
        }, () => {});
    }
  }

  // --- Media CRUD ---
  getMedia(): MediaItem[] {
    return [...this.media];
  }

  saveMedia(item: MediaItem, addToActivePlaylist = false): void {
    const idx = this.media.findIndex((m) => m.id === item.id);
    if (idx >= 0) {
      this.media[idx] = item;
    } else {
      this.media.unshift(item);
    }

    if (addToActivePlaylist) {
      let activePlaylist = this.playlists[0];
      if (!activePlaylist) {
        activePlaylist = {
          id: `pl-${Date.now()}`,
          name: 'Programação Principal',
          description: 'Grade de slides ativa na TV',
          items: [],
          isDefault: true,
          updatedAt: new Date().toISOString(),
        };
        this.playlists.push(activePlaylist);
      }

      const newItem: PlaylistItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        mediaId: item.id,
        durationSeconds: item.durationDefault || 12,
        order: activePlaylist.items.length,
        customTitle: item.title,
        brandConfig: item.brandConfig,
        qrConfig: item.qrConfig,
        categoryOverlay: item.categoryOverlay,
      };

      activePlaylist.items.push(newItem);
      activePlaylist.updatedAt = new Date().toISOString();
      this.savePlaylist(activePlaylist);
    }

    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('media')
        .upsert({
          id: item.id,
          title: item.title,
          type: item.type,
          url: item.url,
          thumbnail: item.thumbnail || null,
          duration_default: item.durationDefault,
          category: item.category,
          brand_config: item.brandConfig || null,
          qr_config: item.qrConfig || null,
          category_overlay: item.categoryOverlay || null,
          file_size: item.fileSize || null,
          dimensions: item.dimensions || null,
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase media save warning:', error.message);
        }, () => {});
    }
  }

  deleteMedia(id: string): void {
    this.media = this.media.filter((m) => m.id !== id);
    this.playlists.forEach((p) => {
      p.items = p.items.filter((item) => item.mediaId !== id);
    });
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('media')
        .delete()
        .eq('id', id)
        .then(({ error }) => {
          if (error) console.warn('Supabase media delete warning:', error.message);
        }, () => {});
    }
  }

  // --- Playlists CRUD ---
  getPlaylists(): Playlist[] {
    return [...this.playlists];
  }

  getPlaylist(id: string): Playlist | undefined {
    return this.playlists.find((p) => p.id === id);
  }

  savePlaylist(playlist: Playlist): void {
    const idx = this.playlists.findIndex((p) => p.id === playlist.id);
    const updated = { ...playlist, updatedAt: new Date().toISOString() };
    if (idx >= 0) {
      this.playlists[idx] = updated;
    } else {
      this.playlists.push(updated);
    }
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('playlists')
        .upsert({
          id: updated.id,
          name: updated.name,
          description: updated.description,
          screen_id: updated.screenId || 'all',
          items: updated.items,
          is_default: Boolean(updated.isDefault),
          updated_at: updated.updatedAt,
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase playlist save warning:', error.message);
        }, () => {});
    }
  }

  deletePlaylist(id: string): void {
    this.playlists = this.playlists.filter((p) => p.id !== id);
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('playlists')
        .delete()
        .eq('id', id)
        .then(({ error }) => {
          if (error) console.warn('Supabase playlist delete warning:', error.message);
        }, () => {});
    }
  }

  updatePlaylistItem(playlistId: string, item: PlaylistItem): void {
    const playlist = this.playlists.find((p) => p.id === playlistId);
    if (!playlist) return;
    const idx = playlist.items.findIndex((i) => i.id === item.id);
    if (idx >= 0) {
      playlist.items[idx] = item;
      playlist.updatedAt = new Date().toISOString();
      this.savePlaylist(playlist);
    }
  }

  duplicatePlaylistItem(playlistId: string, itemId: string): PlaylistItem | null {
    const playlist = this.playlists.find((p) => p.id === playlistId);
    if (!playlist) return null;
    const item = playlist.items.find((i) => i.id === itemId);
    if (!item) return null;

    const duplicated: PlaylistItem = {
      ...JSON.parse(JSON.stringify(item)),
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      customTitle: `${item.customTitle || 'Slide'} (Cópia)`,
      order: playlist.items.length,
    };
    playlist.items.push(duplicated);
    playlist.updatedAt = new Date().toISOString();
    this.savePlaylist(playlist);
    return duplicated;
  }

  getConfig(): SystemConfig {
    return { ...this.config };
  }

  saveConfig(cfg: Partial<SystemConfig>): void {
    this.config = { ...this.config, ...cfg };
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('system_config')
        .upsert({
          id: 'default',
          organization_name: this.config.organizationName,
          brand_profile: this.config.brandProfile,
          theme_accent: this.config.themeAccent,
          theme_mode: this.config.themeMode,
          default_layout_mode: this.config.defaultLayoutMode,
          enable_split_mode: this.config.enableSplitMode,
          updated_at: new Date().toISOString(),
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase config save warning:', error.message);
        }, () => {});
    }
  }

  getTicker(): TickerConfig {
    return { ...this.ticker };
  }

  saveTicker(ticker: TickerConfig): void {
    this.ticker = { ...ticker };
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('ticker_config')
        .upsert({
          id: 'default',
          enabled: this.ticker.enabled,
          text: this.ticker.text,
          speed: this.ticker.speed,
          accent_title: this.ticker.accentTitle || 'AVISO AO VIVO',
          preset_topic: this.ticker.presetTopic || 'retail',
          updated_at: new Date().toISOString(),
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase ticker save warning:', error.message);
        }, () => {});
    }
  }

  getWeather(): WeatherConfig {
    return { ...this.weather };
  }

  saveWeather(weather: WeatherConfig): void {
    this.weather = { ...weather };
    this.saveToStorage();

    const client = this.getActiveCloudClient();
    if (client) {
      client
        .from('weather_config')
        .upsert({
          id: 'default',
          auto_detect: this.weather.autoDetect,
          city: this.weather.city,
          state_code: this.weather.stateCode,
          latitude: this.weather.latitude,
          longitude: this.weather.longitude,
          temp: this.weather.temp,
          temp_min: this.weather.tempMin,
          temp_max: this.weather.tempMax,
          condition: this.weather.condition,
          condition_text: this.weather.conditionText,
          humidity: this.weather.humidity,
          wind_km_h: this.weather.windKmH,
          last_fetched_at: this.weather.lastFetchedAt,
          source: this.weather.source,
        })
        .then(({ error }) => {
          if (error) console.warn('Supabase weather save warning:', error.message);
        }, () => {});
    }
  }

  getLastSyncTime(): string | null {
    return this.lastSyncTime;
  }

  loadDemoPack(): void {
    this.media = DEMO_PRESET_PACK;
    const defaultItems: PlaylistItem[] = this.media.map((m, idx) => ({
      id: `item-${m.id}`,
      mediaId: m.id,
      durationSeconds: m.durationDefault || 12,
      order: idx,
      customTitle: m.title,
      brandConfig: m.brandConfig,
      qrConfig: m.qrConfig,
      categoryOverlay: m.categoryOverlay,
    }));

    this.playlists = [
      {
        id: 'playlist-padrao',
        name: 'Programação de Exemplo',
        description: 'Slides de demonstração com Cardápio, Ofertas e QR Code.',
        items: defaultItems,
        isDefault: true,
        updatedAt: new Date().toISOString(),
      },
    ];

    this.screens = [
      {
        id: 'scr-tv-1',
        name: 'TV Principal 1',
        location: 'Salão Principal',
        slug: 'tv-principal',
        pairingCode: 'TV-1001',
        activePlaylistId: 'playlist-padrao',
        status: 'online',
        resolution: '1080p',
        orientation: 'landscape',
        aspectRatio: '16:9',
        lastPing: new Date().toISOString(),
        pairedAt: new Date().toISOString(),
      },
    ];
    this.saveToStorage();
    if (!supabaseService.isSchemaKnownMissing()) {
      this.pushAllToSupabase();
    }
  }

  clearAll(): void {
    this.screens = [];
    this.media = [];
    this.playlists = [];
    this.saveToStorage();
  }
}

export const db = new ResilientDatabase();
