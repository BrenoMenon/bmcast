import { createClient, SupabaseClient } from '@supabase/supabase-js';

export const DEFAULT_SUPABASE_URL = 'https://dkjjgszyrkhdcrwycaej.supabase.co';
export const DEFAULT_SUPABASE_KEY = 'sb_publishable_kyAFAx-RJG9MTLjTMmySTw_qoIqy9bD';

const STORAGE_KEYS = {
  URL: 'bmcast_supabase_url',
  KEY: 'bmcast_supabase_key',
  ENABLED: 'bmcast_supabase_enabled',
};

export const SUPABASE_SQL_SCHEMA = `-- ==============================================================================
-- BM CAST: Schema Oficial do Banco de Dados Supabase
-- Copie e cole este script no SQL Editor do seu painel Supabase:
-- https://supabase.com/dashboard/project/dkjjgszyrkhdcrwycaej/sql
-- ==============================================================================

-- 1. Habilitar UUID
create extension if not exists "uuid-ossp";

-- 2. Tabela de Telas e Displays (Smart TVs, Telões, Monitores)
create table if not exists public.screens (
  id text primary key,
  name text not null,
  location text default '',
  slug text not null unique,
  pairing_code text default '',
  active_playlist_id text default '',
  status text default 'online',
  resolution text default '1080p',
  orientation text default 'landscape',
  aspect_ratio text default '16:9',
  layout_mode text default 'clean_media',
  brand_name text,
  brand_slogan text,
  brand_logo text,
  last_ping timestamptz default now(),
  paired_at timestamptz default now(),
  notes text,
  created_at timestamptz default now()
);

-- 3. Tabela de Mídias e Slides
create table if not exists public.media (
  id text primary key,
  title text not null,
  type text default 'image',
  url text not null,
  thumbnail text,
  duration_default integer default 12,
  category text default 'cardapio',
  brand_config jsonb,
  qr_config jsonb,
  category_overlay jsonb,
  file_size text,
  dimensions text,
  created_at timestamptz default now()
);

-- 4. Tabela de Playlists (Grades de Programação)
create table if not exists public.playlists (
  id text primary key,
  name text not null,
  description text default '',
  screen_id text default 'all',
  items jsonb default '[]'::jsonb,
  is_default boolean default false,
  updated_at timestamptz default now(),
  created_at timestamptz default now()
);

-- 5. Tabela de Configurações da Empresa e Marca
create table if not exists public.system_config (
  id text primary key default 'default',
  organization_name text default '',
  brand_profile jsonb default '{}'::jsonb,
  theme_accent text default '#2563EB',
  theme_mode text default 'dark',
  default_layout_mode text default 'clean_media',
  enable_split_mode boolean default true,
  updated_at timestamptz default now()
);

-- 6. Tabela do Letreiro Digital (Ticker)
create table if not exists public.ticker_config (
  id text primary key default 'default',
  enabled boolean default true,
  text text not null,
  speed text default 'normal',
  accent_title text default 'AVISO AO VIVO',
  preset_topic text default 'retail',
  updated_at timestamptz default now()
);

-- 7. Tabela de Clima e Previsão do Tempo
create table if not exists public.weather_config (
  id text primary key default 'default',
  auto_detect boolean default false,
  city text default 'São Paulo',
  state_code text default 'SP',
  latitude double precision default -23.5505,
  longitude double precision default -46.6333,
  temp double precision default 24,
  temp_min double precision default 18,
  temp_max double precision default 27,
  condition text default 'partly_cloudy',
  condition_text text default 'Parcialmente Nublado',
  humidity integer default 58,
  wind_km_h double precision default 12,
  last_fetched_at timestamptz default now(),
  source text default 'open_meteo_live'
);

-- 8. Ativação de RLS (Row Level Security)
alter table public.screens enable row level security;
alter table public.media enable row level security;
alter table public.playlists enable row level security;
alter table public.system_config enable row level security;
alter table public.ticker_config enable row level security;
alter table public.weather_config enable row level security;

-- 9. Políticas de Leitura e Escrita Públicas (para os Displays e Painel do BM CAST)
drop policy if exists "BMCAST screens all" on public.screens;
create policy "BMCAST screens all" on public.screens for all using (true) with check (true);

drop policy if exists "BMCAST media all" on public.media;
create policy "BMCAST media all" on public.media for all using (true) with check (true);

drop policy if exists "BMCAST playlists all" on public.playlists;
create policy "BMCAST playlists all" on public.playlists for all using (true) with check (true);

drop policy if exists "BMCAST system_config all" on public.system_config;
create policy "BMCAST system_config all" on public.system_config for all using (true) with check (true);

drop policy if exists "BMCAST ticker_config all" on public.ticker_config;
create policy "BMCAST ticker_config all" on public.ticker_config for all using (true) with check (true);

drop policy if exists "BMCAST weather_config all" on public.weather_config;
create policy "BMCAST weather_config all" on public.weather_config for all using (true) with check (true);

-- 10. Habilitar Publicação Realtime para Atualização Instantânea nas TVs
do $$
begin
  if not exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    create publication supabase_realtime;
  end if;
end $$;

alter publication supabase_realtime add table public.screens, public.media, public.playlists, public.system_config, public.ticker_config, public.weather_config;
`;

export interface SupabaseTestResult {
  connected: boolean;
  message: string;
  hasTables: boolean;
  missingTables?: string[];
  details?: string;
}

class SupabaseService {
  private client: SupabaseClient | null = null;
  private url: string = '';
  private key: string = '';
  private isConfigured: boolean = false;

  constructor() {
    this.initCredentials();
  }

  private initCredentials() {
    if (typeof window === 'undefined') return;

    try {
      const storedUrl = localStorage.getItem(STORAGE_KEYS.URL);
      const storedKey = localStorage.getItem(STORAGE_KEYS.KEY);
      const storedEnabled = localStorage.getItem(STORAGE_KEYS.ENABLED);

      // Usar credenciais salvas ou preencher com as credenciais padrão do usuário
      this.url = (storedUrl || DEFAULT_SUPABASE_URL).trim();
      this.key = (storedKey || DEFAULT_SUPABASE_KEY).trim();
      this.isConfigured = storedEnabled === null ? true : storedEnabled === 'true';

      if (this.url && this.key && this.isConfigured) {
        this.client = createClient(this.url, this.key, {
          auth: {
            persistSession: true,
            autoRefreshToken: true,
          },
        });
      }
    } catch (e) {
      console.warn('Erro ao inicializar Supabase credentials:', e);
    }
  }

  getClient(): SupabaseClient | null {
    if (!this.client && this.url && this.key) {
      try {
        this.client = createClient(this.url, this.key);
      } catch (err) {
        console.error('Falha ao criar cliente Supabase:', err);
      }
    }
    return this.client;
  }

  getCredentials() {
    return {
      url: this.url || DEFAULT_SUPABASE_URL,
      key: this.key || DEFAULT_SUPABASE_KEY,
      isConfigured: this.isConfigured,
    };
  }

  setCredentials(url: string, key: string, enabled = true) {
    this.url = url.trim();
    this.key = key.trim();
    this.isConfigured = enabled;

    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.URL, this.url);
      localStorage.setItem(STORAGE_KEYS.KEY, this.key);
      localStorage.setItem(STORAGE_KEYS.ENABLED, String(enabled));
      // Clear cached missing-table flag when credentials change
      localStorage.removeItem(`bmcast_schema_missing_${this.url}`);
    }

    if (this.url && this.key && enabled) {
      this.client = createClient(this.url, this.key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
      });
    } else {
      this.client = null;
    }
  }

  isSchemaKnownMissing(): boolean {
    if (typeof window === 'undefined') return false;
    try {
      const ts = localStorage.getItem(`bmcast_schema_missing_${this.url}`);
      if (!ts) return false;
      // Re-probe automatically after 15 minutes or immediately on manual test/sync
      if (Date.now() - Number(ts) > 15 * 60 * 1000) {
        localStorage.removeItem(`bmcast_schema_missing_${this.url}`);
        return false;
      }
      return true;
    } catch {
      return false;
    }
  }

  markSchemaStatus(ready: boolean) {
    if (typeof window === 'undefined') return;
    try {
      if (ready) {
        localStorage.removeItem(`bmcast_schema_missing_${this.url}`);
      } else {
        localStorage.setItem(`bmcast_schema_missing_${this.url}`, String(Date.now()));
      }
    } catch {
      /* ignore */
    }
  }

  /**
   * Testa a conectividade com o Supabase sem falhar no endpoint REST com chaves sb_publishable.
   * Verifica também se as tabelas principais já foram criadas.
   */
  async testConnection(testUrl?: string, testKey?: string): Promise<SupabaseTestResult> {
    const url = (testUrl || this.url || DEFAULT_SUPABASE_URL).trim().replace(/\/$/, '');
    const key = (testKey || this.key || DEFAULT_SUPABASE_KEY).trim();

    if (!url || !key) {
      return {
        connected: false,
        hasTables: false,
        message: 'URL e Chave da API do Supabase são obrigatórias.',
      };
    }

    // 1. Testa autenticação / status do projeto via auth settings
    let apiReachable = false;
    try {
      const authRes = await fetch(`${url}/auth/v1/settings`, {
        method: 'GET',
        headers: {
          apikey: key,
          Authorization: `Bearer ${key}`,
        },
      });

      if (authRes.ok) {
        apiReachable = true;
      } else if (authRes.status === 401 || authRes.status === 403) {
        const retryRes = await fetch(`${url}/auth/v1/settings`, {
          method: 'GET',
          headers: { apikey: key },
        });
        if (retryRes.ok) {
          apiReachable = true;
        } else {
          return {
            connected: false,
            hasTables: false,
            message: `Chave do Supabase inválida ou não autorizada (Status HTTP ${retryRes.status}).`,
          };
        }
      }
    } catch (e: any) {
      return {
        connected: false,
        hasTables: false,
        message: `Não foi possível conectar ao servidor Supabase em "${url}". Verifique sua conexão e o endereço do projeto.`,
        details: e?.message,
      };
    }

    // 2. Cria cliente temporário para verificar existência das tabelas
    try {
      const tempClient = createClient(url, key);
      const tablesToCheck = ['screens', 'media', 'playlists', 'system_config', 'ticker_config', 'weather_config'];
      const missing: string[] = [];

      // Probe first table; if missing, avoid firing 5 extra 404 requests
      const firstCheck = await tempClient.from('screens').select('id').limit(1);
      if (
        firstCheck.error &&
        (firstCheck.error.code === 'PGRST205' ||
          firstCheck.error.code === '42P01' ||
          firstCheck.error.message.includes('Could not find the table') ||
          firstCheck.error.message.includes('does not exist'))
      ) {
        this.markSchemaStatus(false);
        return {
          connected: true,
          hasTables: false,
          missingTables: tablesToCheck,
          message: 'Conectado à API do Supabase! Falta apenas executar o Script SQL abaixo para criar as tabelas.',
          details: 'Copie o Script SQL no botão abaixo, cole no SQL Editor do Supabase e clique em Run.',
        };
      }

      for (const table of tablesToCheck.slice(1)) {
        const { error } = await tempClient.from(table).select('id').limit(1);
        if (error) {
          if (
            error.code === 'PGRST205' ||
            error.code === '42P01' ||
            error.message.includes('Could not find the table') ||
            error.message.includes('does not exist')
          ) {
            missing.push(table);
          }
        }
      }

      if (missing.length === 0) {
        this.markSchemaStatus(true);
        return {
          connected: true,
          hasTables: true,
          message: 'Conexão estabelecida com sucesso! Todas as tabelas estão prontas e sincronizadas.',
        };
      } else {
        this.markSchemaStatus(false);
        return {
          connected: true,
          hasTables: false,
          missingTables: missing,
          message: 'Conectado à API do Supabase! Algumas tabelas ainda precisam ser criadas no SQL Editor.',
          details: `Tabelas pendentes: ${missing.join(', ')}`,
        };
      }
    } catch (e: any) {
      return {
        connected: apiReachable,
        hasTables: false,
        message: apiReachable
          ? 'Conectado à API do Supabase, mas tabelas ainda não foram inicializadas.'
          : 'Erro ao verificar tabelas do Supabase.',
        details: e?.message,
      };
    }
  }
}

export const supabaseService = new SupabaseService();
