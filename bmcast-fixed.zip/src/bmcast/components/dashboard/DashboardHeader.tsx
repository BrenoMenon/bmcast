import React, { useState } from 'react';
import {
  CloudSun,
  Store,
  Radio,
  Plus,
  LogOut,
  Menu,
  X,
  Tv,
  HelpCircle,
  Database,
  Sun,
  Moon,
  Wifi,
  Download,
} from 'lucide-react';
import { Logo } from '../common/Logo';
import { WeatherConfig, Screen, CompanyBrandProfile } from '../../types/signage';

interface DashboardHeaderProps {
  screens: Screen[];
  selectedScreenSlug: string;
  onSelectScreenSlug: (slug: string) => void;
  weather: WeatherConfig;
  brandProfile: CompanyBrandProfile;
  themeMode: 'dark' | 'light';
  onToggleTheme: () => void;
  onOpenWeatherModal: () => void;
  onOpenBrandModal: () => void;
  onOpenTickerModal: () => void;
  onOpenNewSlideModal: () => void;
  onOpenConnectTVModal: () => void;
  onOpenTutorialModal: () => void;
  onOpenSupabaseModal: () => void;
  onLaunchPlayer: (slug: string) => void;
  onSignOut?: (() => void) | undefined;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  screens,
  selectedScreenSlug,
  onSelectScreenSlug,
  weather,
  brandProfile,
  themeMode,
  onToggleTheme,
  onOpenWeatherModal,
  onOpenBrandModal,
  onOpenTickerModal,
  onOpenNewSlideModal,
  onOpenConnectTVModal,
  onOpenTutorialModal,
  onOpenSupabaseModal,
  onSignOut,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md sticky top-0 z-40 transition-colors">
      {/* PRIMARY BAR */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Left: Brand mark + Active TV Selector */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <Logo size="sm" />

          {screens.length > 0 && (
            <div className="hidden md:flex items-center gap-2 pl-3 sm:pl-4 border-l border-slate-200 dark:border-slate-800 min-w-0">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold whitespace-nowrap">
                TV Ativa:
              </span>
              <select
                value={selectedScreenSlug}
                onChange={(e) => onSelectScreenSlug(e.target.value)}
                aria-label="Selecionar TV Ativa"
                className="max-w-[190px] xl:max-w-[240px] truncate bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-semibold focus:outline-none focus:border-sky-500 cursor-pointer transition-colors"
              >
                {screens.map((sc) => (
                  <option
                    key={sc.id}
                    value={sc.slug}
                    className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {sc.name} ({sc.orientation === 'landscape' ? '16:9' : '9:16'})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Desktop Primary Actions (Right) */}
        <div className="hidden lg:flex items-center gap-2.5 shrink-0">
          {/* Live Weather Quick Status */}
          <button
            type="button"
            onClick={onOpenWeatherModal}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 transition-colors cursor-pointer whitespace-nowrap"
            title="Configurar cidade e previsão do tempo ao vivo"
          >
            <CloudSun className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
            <span className="font-bold text-slate-900 dark:text-white tabular-nums">{weather.temp}°C</span>
            <span className="text-slate-400 dark:text-slate-500">·</span>
            <span className="text-slate-600 dark:text-slate-300 max-w-[110px] truncate">{weather.city}</span>
          </button>

          {/* Explicit Light / Dark Theme Toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={themeMode === 'dark' ? 'Ativar Modo Claro' : 'Ativar Modo Escuro'}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            title={themeMode === 'dark' ? 'Alternar para Modo Claro' : 'Alternar para Modo Escuro'}
          >
            {themeMode === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Claro</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-sky-600 shrink-0" />
                <span>Escuro</span>
              </>
            )}
          </button>

          <div className="h-5 w-px bg-slate-200 dark:bg-slate-800 mx-0.5" />

          {/* Conectar TV Button */}
          <button
            type="button"
            onClick={onOpenConnectTVModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-sky-50 hover:bg-sky-100 dark:bg-slate-800 dark:hover:bg-slate-700 border border-sky-200 dark:border-sky-500/40 text-sky-800 dark:text-sky-300 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0"
            title="Gerar Link e QR Code para Telões e Smart TVs"
          >
            <Wifi className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>Conectar TV</span>
          </button>

          {/* Criar Slide - Primary CTA */}
          <button
            type="button"
            onClick={onOpenNewSlideModal}
            className="flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-[0.98] text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5 shrink-0" />
            <span>Criar Slide</span>
          </button>

          {/* Sign Out */}
          {onSignOut && (
            <button
              type="button"
              onClick={onSignOut}
              aria-label="Sair da conta"
              className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors cursor-pointer shrink-0"
              title="Sair da conta"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Mobile / Tablet Compact Controls */}
        <div className="flex lg:hidden items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={themeMode === 'dark' ? 'Ativar Modo Claro' : 'Ativar Modo Escuro'}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 cursor-pointer"
            title={themeMode === 'dark' ? 'Ativar Modo Claro' : 'Ativar Modo Escuro'}
          >
            {themeMode === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-500" />
            ) : (
              <Moon className="w-4 h-4 text-sky-600" />
            )}
          </button>

          <button
            type="button"
            onClick={onOpenConnectTVModal}
            aria-label="Conectar TV"
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-sky-600 dark:text-sky-400 border border-slate-200 dark:border-slate-700 cursor-pointer"
            title="Conectar TV"
          >
            <Tv className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenNewSlideModal}
            className="flex items-center gap-1 px-3 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Slide</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={mobileMenuOpen}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* DESKTOP SECONDARY WORKSPACE UTILITY BAR (Zero Overflow, Clean Hierarchy) */}
      <div className="hidden lg:block border-t border-slate-200/80 dark:border-slate-800/80 bg-slate-50/90 dark:bg-slate-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-10 flex items-center justify-between gap-4 text-xs">
          {/* Left: Station Settings */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onOpenBrandModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/80 font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <Store className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              <span>{brandProfile.name ? `Empresa: ${brandProfile.name}` : 'Dados da Empresa'}</span>
            </button>

            <span className="text-slate-300 dark:text-slate-700">·</span>

            <button
              type="button"
              onClick={onOpenTickerModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/80 font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <Radio className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              <span>Letreiro de Rodapé</span>
            </button>

            <span className="text-slate-300 dark:text-slate-700">·</span>

            <button
              type="button"
              onClick={onOpenTutorialModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/80 font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>Como Usar na TV</span>
            </button>
          </div>

          {/* Right: Cloud DB & Source Download */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenSupabaseModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-emerald-700 hover:bg-emerald-100/70 dark:text-emerald-300 dark:hover:bg-emerald-950/60 font-semibold transition-colors cursor-pointer whitespace-nowrap"
              title="Gerenciar Banco de Dados Supabase (Nuvem)"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Banco Supabase</span>
            </button>

            <span className="text-slate-300 dark:text-slate-700">·</span>

            <a
              href="/bmcast-fixed.zip"
              download="bmcast-fixed.zip"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/80 font-medium transition-colors cursor-pointer whitespace-nowrap"
              title="Baixar código-fonte completo e atualizado em ZIP"
            >
              <Download className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              <span>Baixar .ZIP</span>
            </a>
          </div>
        </div>
      </div>

      {/* MOBILE DRAWER */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-3 animate-in slide-in-from-top-2 duration-150 shadow-xl">
          {screens.length > 0 && (
            <div className="space-y-1">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-bold">
                Tela da TV Selecionada:
              </span>
              <select
                value={selectedScreenSlug}
                onChange={(e) => {
                  onSelectScreenSlug(e.target.value);
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-xs text-slate-900 dark:text-white font-semibold"
              >
                {screens.map((sc) => (
                  <option
                    key={sc.id}
                    value={sc.slug}
                    className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {sc.name} ({sc.location})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                onOpenWeatherModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left text-xs text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <CloudSun className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 dark:text-white">{weather.temp}°C</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{weather.city}</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenConnectTVModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-sky-50 dark:bg-slate-800 border border-sky-200 dark:border-sky-500/40 text-left text-xs text-sky-900 dark:text-slate-200 cursor-pointer"
            >
              <Wifi className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-sky-900 dark:text-white">Conectar TV</div>
                <div className="text-[10px] text-sky-700 dark:text-slate-400 truncate">Link &amp; QR Code</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenBrandModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left text-xs text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <Store className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 dark:text-white">Empresa</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">Logo e Cores</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenTickerModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left text-xs text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <Radio className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 dark:text-white">Letreiro</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">Rodapé da TV</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenTutorialModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left text-xs text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 dark:text-white">Tutorial</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">Como usar a TV</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenSupabaseModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 text-left text-xs text-emerald-900 dark:text-emerald-300 cursor-pointer"
            >
              <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 dark:text-white">Supabase</div>
                <div className="text-[10px] text-emerald-700 dark:text-emerald-400 truncate">Banco Nuvem</div>
              </div>
            </button>

            <a
              href="/bmcast-fixed.zip"
              download="bmcast-fixed.zip"
              onClick={() => setMobileMenuOpen(false)}
              className="col-span-2 flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <Download className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <span>Baixar Código Completo (.ZIP)</span>
            </a>

            {onSignOut && (
              <button
                type="button"
                onClick={() => {
                  onSignOut();
                  setMobileMenuOpen(false);
                }}
                className="col-span-2 flex items-center justify-center gap-2 p-2.5 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-xs font-bold text-red-600 dark:text-red-300 cursor-pointer"
              >
                <LogOut className="w-4 h-4 text-red-500 dark:text-red-400" />
                <span>Desconectar da Conta</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
