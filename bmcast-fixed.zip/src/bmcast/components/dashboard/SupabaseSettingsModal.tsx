import React, { useState } from 'react';
import {
  X,
  Database,
  CheckCircle2,
  AlertCircle,
  Key,
  Globe,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  Copy,
  Check,
  Download,
  UploadCloud,
  FileCode2,
} from 'lucide-react';
import {
  supabaseService,
  SUPABASE_SQL_SCHEMA,
  DEFAULT_SUPABASE_URL,
  DEFAULT_SUPABASE_KEY,
} from '../../services/supabaseClient';
import { storageService } from '../../services/storageService';

interface SupabaseSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  supabaseUrl?: string | undefined;
  supabaseAnonKey?: string | undefined;
  onSave: (url: string, anonKey: string, enabled: boolean) => void;
}

export const SupabaseSettingsModal: React.FC<SupabaseSettingsModalProps> = ({
  isOpen,
  onClose,
  supabaseUrl: initialUrl = DEFAULT_SUPABASE_URL,
  supabaseAnonKey: initialKey = DEFAULT_SUPABASE_KEY,
  onSave,
}) => {
  const [url, setUrl] = useState(initialUrl || DEFAULT_SUPABASE_URL);
  const [anonKey, setAnonKey] = useState(initialKey || DEFAULT_SUPABASE_KEY);
  const [isTesting, setIsTesting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlPreview, setShowSqlPreview] = useState(false);
  const [testResult, setTestResult] = useState<{
    connected: boolean;
    hasTables: boolean;
    message: string;
    missingTables?: string[] | undefined;
    details?: string | undefined;
  } | null>(null);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await supabaseService.testConnection(url, anonKey);
      setTestResult(res);
    } catch (e: any) {
      setTestResult({
        connected: false,
        hasTables: false,
        message: 'Erro inesperado ao testar conexão: ' + (e?.message || 'Erro de rede'),
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSyncNow = async () => {
    setIsSyncing(true);
    try {
      const res = await storageService.pushAllToSupabase();
      if (res.success) {
        await storageService.syncFromSupabase();
        setTestResult({
          connected: true,
          hasTables: true,
          message: 'Sincronização em tempo real concluída com sucesso!',
        });
      } else {
        setTestResult({
          connected: true,
          hasTables: false,
          message: res.message,
        });
      }
    } catch (e: any) {
      setTestResult({
        connected: false,
        hasTables: false,
        message: 'Falha na sincronização: ' + (e?.message || 'Erro'),
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleSave = () => {
    const cleanUrl = url.trim();
    const cleanKey = anonKey.trim();
    supabaseService.setCredentials(cleanUrl, cleanKey, Boolean(cleanUrl && cleanKey));
    onSave(cleanUrl, cleanKey, Boolean(cleanUrl && cleanKey));
    onClose();
  };

  const projectRef = url.match(/https?:\/\/([^.]+)\.supabase\.co/)?.[1] || 'dkjjgszyrkhdcrwycaej';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] transition-colors">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-50 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight flex flex-wrap items-center gap-2">
                <span>Banco de Dados &amp; Nuvem Supabase</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30">
                  Pronto para uso
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sincronização em tempo real para TV corporativa, playlists e slides
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {/* Status Banner */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">Status da Conexão:</span>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-500/15 border border-emerald-200 dark:border-emerald-500/30 text-emerald-800 dark:text-emerald-300">
                  Resiliente &amp; Híbrido (Local + Supabase)
                </span>
              </div>
              <a
                href={`https://supabase.com/dashboard/project/${projectRef}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1 font-semibold transition-colors"
              >
                Abrir Dashboard <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              O BM CAST opera em modo híbrido de alta disponibilidade: seus dados salvam instantaneamente no navegador e sincronizam com a nuvem do <strong>Supabase</strong>.
            </p>
          </div>

          {/* Inputs */}
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5 flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  Supabase Project URL:
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">Projeto: {projectRef}</span>
              </label>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://xyzcompany.supabase.co"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-sky-500 font-mono transition-colors"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5 flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  Supabase API Key (Publishable / Anon Key):
                </span>
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                  Chave pública segura para TV &amp; Web
                </span>
              </label>
              <input
                type="password"
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                placeholder="sb_publishable_... ou eyJhbGciOi..."
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-sky-500 font-mono transition-colors"
              />
            </div>
          </div>

          {/* Actions Bar: Testar e Sincronizar */}
          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-sky-600 dark:text-sky-400' : ''}`} />
              <span>{isTesting ? 'Verificando...' : 'Testar Conexão com Supabase'}</span>
            </button>

            <button
              type="button"
              onClick={handleSyncNow}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-4 py-2 bg-sky-50 hover:bg-sky-100 dark:bg-sky-600/20 dark:hover:bg-sky-600/30 text-sky-800 dark:text-sky-300 text-xs font-semibold rounded-xl border border-sky-200 dark:border-sky-500/40 transition-colors cursor-pointer disabled:opacity-50"
            >
              <UploadCloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-bounce' : ''}`} />
              <span>{isSyncing ? 'Sincronizando...' : 'Enviar Dados Locais para Nuvem'}</span>
            </button>
          </div>

          {/* Test Status feedback */}
          {testResult && (
            <div
              className={`p-4 rounded-2xl border text-xs space-y-1.5 animate-in fade-in ${
                testResult.connected
                  ? testResult.hasTables
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/80 text-emerald-900 dark:text-emerald-200'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/80 text-amber-900 dark:text-amber-200'
                  : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800/80 text-red-900 dark:text-red-200'
              }`}
            >
              <div className="flex items-center gap-2 font-bold">
                {testResult.connected ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600 dark:text-red-400" />
                )}
                <span>{testResult.message}</span>
              </div>
              {testResult.details && (
                <p className="text-[11px] opacity-90 pl-6">{testResult.details}</p>
              )}
            </div>
          )}

          {/* SQL Setup Helper Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <FileCode2 className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  Criar Tabelas no Supabase (SQL Editor)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={`https://supabase.com/dashboard/project/${projectRef}/sql`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-[11px] font-semibold rounded-lg border border-slate-300 dark:border-slate-700 flex items-center gap-1 transition-colors"
                >
                  Abrir SQL Editor <ExternalLink className="w-3 h-3" />
                </a>
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-3 h-3 text-white" />
                      <span>Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copiar Script SQL</span>
                    </>
                  )}
                </button>
              </div>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              Para persistir os dados no seu banco do Supabase, copie o script acima, abra o SQL Editor do seu projeto e clique em <strong>Run</strong>. O script cria as tabelas <code className="text-sky-700 dark:text-sky-300 font-semibold">screens</code>, <code className="text-sky-700 dark:text-sky-300 font-semibold">media</code>, <code className="text-sky-700 dark:text-sky-300 font-semibold">playlists</code>, <code className="text-sky-700 dark:text-sky-300 font-semibold">system_config</code>, <code className="text-sky-700 dark:text-sky-300 font-semibold">ticker_config</code>, e ativa o Realtime automático.
            </p>
            <button
              type="button"
              onClick={() => setShowSqlPreview(!showSqlPreview)}
              className="text-[11px] font-semibold text-sky-600 dark:text-sky-400 hover:underline cursor-pointer block"
            >
              {showSqlPreview ? 'Ocultar visualização do código SQL' : 'Visualizar código SQL completo'}
            </button>
            {showSqlPreview && (
              <pre className="max-h-48 overflow-y-auto p-3 rounded-xl bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-200 leading-relaxed">
                {SUPABASE_SQL_SCHEMA}
              </pre>
            )}
          </div>

          {/* Download Zip Section */}
          <div className="p-4 rounded-2xl bg-sky-50/80 dark:bg-slate-800/60 border border-sky-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Download className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                Baixar Projeto Completo em ZIP
              </h4>
              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                Código atualizado, tema claro/escuro funcional, banco Supabase e documentação inclusa.
              </p>
            </div>
            <a
              href="/bmcast-fixed.zip"
              download="bmcast-fixed.zip"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors shrink-0 shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar .ZIP</span>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            Fechar
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2.5 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs"
          >
            Salvar e Conectar
          </button>
        </div>
      </div>
    </div>
  );
};
